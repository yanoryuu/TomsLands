using UnityEngine;

public class StreamingSettingPresenter
{
    public StreamingSettingPresenter(StreamingSettingModel streamingSettingModel)
    {
        
    }
}
