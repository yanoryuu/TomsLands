using System.Collections.Generic;
using UnityEngine;

public class StreamingSettingModel
{
    public List<RuntimeItemData> RuntimeStreamingItems { get; private set; } = new();
    
    public List<RuntimeItemData> StreamingDisplayItems { get; private set; } = new();
    
    public ItemModel itemModel { get; private set; }
    
    public StreamingSettingModel(ItemModel itemModel)
    {
        this.itemModel = itemModel;
    }

    public void LoadData()
    {
        RuntimeStreamingItems = itemModel.RuntimeItems;
    }
    
    public void SetSelectStreamingItem(RuntimeItemData index)
    {
        if (StreamingDisplayItems.Count > 6)
        {
            Debug.LogError("アイテムを消してください");
            return;
        }
        
        StreamingDisplayItems.Add(index);
    }

    public void RemoveSelectStreamingItem(RuntimeItemData index)
    {
        StreamingDisplayItems.Remove(index);
    }
}
