using System;
using System.Collections.Generic;
using R3;
using UnityEngine;

public class StreamingItemModel
{
    public List<StreamingItemPlain> runtimeStreamingItems { get; private set; } = new();
    public ReactiveProperty<float>  trustPenalty           { get; private set; }
    public StealthMarketingModel    stealthMarketingModel { get; private set; }
    
    private CompositeDisposable disposables = new CompositeDisposable();

    public void Initialize()
    {
        runtimeStreamingItems.Clear();
        trustPenalty = new ReactiveProperty<float>(0f);
        stealthMarketingModel = new StealthMarketingModel(200, 20f, 50f, 30f);
    }

    public void LoadStreamingItems(List<StreamingItemPlain> itemDataList)
    {
        runtimeStreamingItems = itemDataList;
    }

    public void UpdateStreamingItems(string itemId, int newPrice)
    {
        var itemData = runtimeStreamingItems.Find(item => item.itemId == itemId);
        if (itemData == null)
        {
            Debug.LogError($"Streaming item with ID {itemId} not found.");
            return;
        }
        itemData.price.Value    = newPrice;
        // itemData.quantity = newQuantity;
    }
    
    public void SetIsSell(string itemId, bool isSell)
    {
        var itemData = runtimeStreamingItems.Find(item => item.itemId == itemId);
        if (itemData == null)
        {
            Debug.LogError($"Streaming item with ID {itemId} not found.");
            return;
        }
        itemData.isSell.Value = isSell;
    }

    public void ApplyBasicStealth(TomsShopModel shop)
        => stealthMarketingModel.PerformBasic(runtimeStreamingItems, shop);

    // public void ApplyFocusedStealth(string itemId, TomsShopModel shop)
    // {
    //     var item = runtimeStreamingItems.Find(i => i.itemId == itemId);
    //     stealthMarketingModel.PerformFocused(item, shop);
    // }
}


[Serializable]
public class StreamingItemPlain
{
    public StreamingItemPlain(string itemId, int price, Sprite icon, int quantity, float demand,bool isSell = false)
    {
        this.itemId = itemId;
        this.price = new ReactiveProperty<int>(price);
        this.icon = icon;
        this.quantity = quantity;
        this.demand = demand;
        this.isSell = new ReactiveProperty<bool>(isSell);
    }
    public string itemId;
    public ReactiveProperty<int> price;
    public Sprite icon;
    public int quantity;
    public float demand;
    public ReactiveProperty<bool> isSell;
}
