using System;
using System.Collections.Generic;
using UnityEngine;

public class StreamingItemModel
{
    public List<StreamingItemPlain> RuntimeStreamingItems { get; private set; }　= new();

    private ItemModel itemModel;
    
    private HeroModel heroModel;
    
    private TomsShopModel tomsShopModel;

    public StreamingItemModel(ItemModel itemModel , TomsShopModel tomsShopModel,HeroModel heroModel)
    {
        this.itemModel = itemModel;
        this.tomsShopModel = tomsShopModel;
        this.heroModel = heroModel;
    }
    
    public void LoadStreamingItems(List<StreamingItemPlain> itemDataList)
    {
        RuntimeStreamingItems = itemDataList;
    }

    public void UpdateStreamingItems(string itemId,int newPrice,int newQuantity)
    {
        var itemData = GetStreamingItemData(itemId);
        if (itemData == null)
        {
            Debug.LogError($"Streaming item with ID {itemId} not found.");
            return;
        }
        
        itemData.price = newPrice;
        itemData.quantity = newQuantity;
    }

    private StreamingItemPlain GetStreamingItemData(string itemId)
    {
        var itemData = RuntimeStreamingItems.Find(item => item.itemId == itemId);
        if (itemData == null)
        {
            Debug.LogError($"Streaming item with ID {itemId} not found.");
            return null;
        }
        return itemData;
    }
}

[Serializable]
public class StreamingItemPlain
{
    public StreamingItemPlain(string itemId, int price, Sprite icon, int quantity, float demand)
    {
        this.itemId = itemId;
        this.price = price;
        this.icon = icon;
        this.quantity = quantity;
        this.demand = demand;
    }
    public string itemId;
    public int price;
    public Sprite icon;
    public int quantity;
    public float demand;
}
